
from django.contrib import admin
from .models import Event, Attendance, Survey, CertificateTemplate

@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title','start','end','location')
    readonly_fields = ('qr_preview',)
    def qr_preview(self, obj):
        if obj.qr_code:
            return '<img src="{}" style="max-width:200px;" />'.format(obj.qr_code.url)
        return 'No QR'
    qr_preview.allow_tags = True
    qr_preview.short_description = 'QR Code Preview'

admin.site.register(Attendance)
admin.site.register(Survey)
admin.site.register(CertificateTemplate)
