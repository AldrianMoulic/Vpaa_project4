
from django.db import models
from django.contrib.auth import get_user_model
from django.utils import timezone
from django.urls import reverse

User = get_user_model()

class Event(models.Model):
    title = models.CharField(max_length=255)
    description = models.TextField(blank=True)
    start = models.DateTimeField()
    end = models.DateTimeField()
    location = models.CharField(max_length=255, blank=True)
    qr_code = models.ImageField(upload_to='qrcodes/', blank=True, null=True)
    default_certificate = models.ImageField(upload_to='certificates/defaults/', blank=True, null=True)

    def __str__(self):
        return self.title

    def get_absolute_url(self):
        return reverse('event_detail', args=[self.pk])

class Attendance(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    event = models.ForeignKey(Event, on_delete=models.CASCADE)
    time_in = models.DateTimeField(blank=True, null=True)
    time_out = models.DateTimeField(blank=True, null=True)
    certificate_sent = models.BooleanField(default=False)

    class Meta:
        unique_together = ('user','event')

    def __str__(self):
        return f"{self.user} - {self.event}"

class Survey(models.Model):
    attendance = models.OneToOneField(Attendance, on_delete=models.CASCADE)
    answers = models.JSONField(default=dict, blank=True)
    completed_at = models.DateTimeField(blank=True, null=True)

    def mark_completed(self):
        self.completed_at = timezone.now()
        self.save()

class CertificateTemplate(models.Model):
    event = models.ForeignKey(Event, on_delete=models.CASCADE, related_name='templates', blank=True, null=True)
    title = models.CharField(max_length=255)
    image = models.ImageField(upload_to='certificates/')
    is_default = models.BooleanField(default=False)

    def __str__(self):
        return self.title
