
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from django.http import HttpResponse, HttpResponseForbidden, FileResponse
from .models import Event, Attendance, Survey, CertificateTemplate
from django.core.files.base import ContentFile
from django.conf import settings
import os

def index(request):
    events = Event.objects.all().order_by('-start')
    return render(request, 'events/index.html', {'events': events})

def event_detail(request, pk):
    event = get_object_or_404(Event, pk=pk)
    return render(request, 'events/detail.html', {'event': event})

@login_required
def time_in(request, pk):
    event = get_object_or_404(Event, pk=pk)
    attendance, created = Attendance.objects.get_or_create(user=request.user, event=event)
    attendance.time_in = timezone.now()
    attendance.save()
    return redirect('event_detail', pk=pk)

@login_required
def time_out(request, pk):
    event = get_object_or_404(Event, pk=pk)
    try:
        attendance = Attendance.objects.get(user=request.user, event=event)
    except Attendance.DoesNotExist:
        return HttpResponseForbidden('You must time in first.')
    attendance.time_out = timezone.now()
    attendance.save()
    return redirect('event_detail', pk=pk)

@login_required
def survey_view(request, pk):
    event = get_object_or_404(Event, pk=pk)
    attendance = Attendance.objects.filter(user=request.user, event=event).first()
    if not attendance:
        return HttpResponseForbidden('You must time in first.')
    survey, created = Survey.objects.get_or_create(attendance=attendance)
    if request.method == 'POST':
        # store posted survey answers as JSON
        answers = {}
        for k, v in request.POST.items():
            if k.startswith('q_'):
                answers[k] = v
        survey.answers = answers
        survey.mark_completed()
        survey.save()
        return redirect('event_detail', pk=pk)
    return render(request, 'events/survey.html', {'event': event})

@login_required
def download_certificate(request, attendance_id):
    attendance = get_object_or_404(Attendance, id=attendance_id, user=request.user)
    # look up generated certificate file (assume stored at media/certificates/generated/{attendance_id}.png)
    path = os.path.join(settings.MEDIA_ROOT, 'certificates', 'generated', f'{attendance_id}.png')
    if os.path.exists(path):
        return FileResponse(open(path, 'rb'), as_attachment=True, filename=f'certificate_{attendance_id}.png')
    return HttpResponse('No certificate found.', status=404)
