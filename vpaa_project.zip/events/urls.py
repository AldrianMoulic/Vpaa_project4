
from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('events/<int:pk>/', views.event_detail, name='event_detail'),
    path('events/<int:pk>/timein/', views.time_in, name='time_in'),
    path('events/<int:pk>/timeout/', views.time_out, name='time_out'),
    path('events/<int:pk>/survey/', views.survey_view, name='survey'),
    path('certificates/<int:attendance_id>/download/', views.download_certificate, name='download_certificate'),
]
