
from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import Event, Attendance, Survey, CertificateTemplate
from django.core.files.base import ContentFile
import qrcode, io, os
from django.conf import settings
from django.core.mail import EmailMessage
from PIL import Image, ImageDraw, ImageFont
from django.utils import timezone

@receiver(post_save, sender=Event)
def create_qr_for_event(sender, instance, created, **kwargs):
    # generate a QR code image that encodes the event URL
    try:
        data = f"Event:{instance.pk}:{instance.title}"

        img = qrcode.make(data)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        filename = f'event_{instance.pk}_qr.png'
        instance.qr_code.save(filename, ContentFile(buf.getvalue()), save=False)
        instance.save()
    except Exception as e:
        print('QR generation failed:', e)

def generate_certificate_image(attendance):
    # create a certificate image, overlay user's name and event title onto a template
    try:
        event = attendance.event
        user = attendance.user
        media_dir = settings.MEDIA_ROOT
        out_dir = os.path.join(media_dir, 'certificates', 'generated')
        os.makedirs(out_dir, exist_ok=True)
        out_path = os.path.join(out_dir, f"{attendance.id}.png")
        # choose template: event.default_certificate or first CertificateTemplate for event or default blank
        template_path = None
        if event.default_certificate and os.path.exists(event.default_certificate.path):
            template_path = event.default_certificate.path
        else:
            tpl = CertificateTemplate.objects.filter(event=event).first()
            if tpl and tpl.image and os.path.exists(tpl.image.path):
                template_path = tpl.image.path
        if not template_path:
            # create a simple blank certificate
            img = Image.new('RGB', (1200, 900), color=(255,255,255))
        else:
            img = Image.open(template_path).convert('RGB')
        draw = ImageDraw.Draw(img)
        try:
            font = ImageFont.truetype('arial.ttf', 48)
        except:
            font = ImageFont.load_default()
        text = f"Certificate of Participation\nThis is to certify that {user.get_full_name() or user.username}\nhas completed the event: {event.title}\non {timezone.localtime(attendance.time_in).strftime('%B %d, %Y') if attendance.time_in else ''}"
        w, h = img.size
        # center text
        lines = text.split('\n')
        y = h//2 - (len(lines)*30)
        for line in lines:
            tw, th = draw.textsize(line, font=font)
            draw.text(((w-tw)/2, y), line, fill=(0,0,0), font=font)
            y += th + 10
        img.save(out_path)
        return out_path
    except Exception as e:
        print('Certificate generation failed:', e)
        return None

@receiver(post_save, sender=Attendance)
def attendance_post_save(sender, instance, created, **kwargs):
    # if user has time_in, time_out and survey completed, generate certificate and email
    try:
        if instance.time_in and instance.time_out:
            survey = getattr(instance, 'survey', None)
            if survey and survey.completed_at and not instance.certificate_sent:
                # generate certificate
                path = generate_certificate_image(instance)
                if path:
                    # email to user with attachment
                    subject = f'Your Certificate for {instance.event.title}'
                    body = 'Congratulations — attached is your certificate of participation.'
                    email = EmailMessage(subject, body, settings.DEFAULT_FROM_EMAIL, [instance.user.email])
                    email.attach_file(path)
                    email.send(fail_silently=True)
                    instance.certificate_sent = True
                    instance.save()
    except Exception as e:
        print('Error in attendance_post_save:', e)
