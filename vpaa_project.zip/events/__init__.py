
# connect signals
default_app_config = 'events.apps.EventsConfig'
