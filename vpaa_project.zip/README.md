
VPAA Event Manager - Django scaffold
===================================

What's included
- A Django project scaffold named `vpaa_project`
- An app `events` with models for Event, Attendance, Survey, CertificateTemplate
- QR-code generation integration (uses `qrcode` library)
- Certificate generation using Pillow
- Signals that automatically generate QR codes on Event creation and send certificate emails
- Frontend templates (simple, clean UI)
- A small script `scripts/generate_qrcodes.py` that can be run to regenerate QR codes for events
- `requirements.txt` listing dependencies

How to run (locally)
1. Create a Python virtualenv and activate it.
2. Install requirements: `pip install -r requirements.txt`
3. Apply migrations:
   - `python manage.py makemigrations`
   - `python manage.py migrate`
4. Create a superuser: `python manage.py createsuperuser`
5. Run development server: `python manage.py runserver`
6. Open http://127.0.0.1:8000/ to see the app.

Notes
- Email sending is configured to use console backend by default (prints emails to terminal). Change settings.py EMAIL_BACKEND, SMTP settings to send real emails.
- The QR-code generation relies on the `qrcode` and `Pillow` packages.
- This scaffold is a starting point — review and secure for production (SECRET_KEY, DEBUG=False, allowed hosts, proper email settings, storage for media files, HTTPS, etc.).
