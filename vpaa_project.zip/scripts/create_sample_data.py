
# Run this script with Django context to create sample events and users.
import os, django
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vpaa_project.settings')
django.setup()
from django.contrib.auth import get_user_model
from events.models import Event
from django.utils import timezone
User = get_user_model()
if not User.objects.filter(username='student').exists():
    User.objects.create_user('student','student@example.com','password', first_name='Demo', last_name='Student')
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser('admin','admin@example.com','password')
if not Event.objects.exists():
    Event.objects.create(title='Orientation 2026', description='Orientation event', start=timezone.now(), end=timezone.now())
    print('Sample event created.')
else:
    print('Events already exist.')
