
"""Utility: regenerate QR codes for all events.
Usage: python scripts/generate_qrcodes.py
This script expects Django settings to be discoverable. A straightforward way to run it is:
    python manage.py runscript scripts/generate_qrcodes.py
or set DJANGO_SETTINGS_MODULE and run directly.
"""
import os, django, io
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'vpaa_project.settings')
django.setup()
from events.models import Event
import qrcode
from django.core.files.base import ContentFile

for e in Event.objects.all():
    try:
        data = f"Event:{e.pk}:{e.title}"
        img = qrcode.make(data)
        buf = io.BytesIO()
        img.save(buf, format='PNG')
        buf.seek(0)
        filename = f'event_{e.pk}_qr.png'
        e.qr_code.save(filename, ContentFile(buf.getvalue()), save=True)
        print('QR saved for', e)
    except Exception as ex:
        print('failed for', e, ex)
